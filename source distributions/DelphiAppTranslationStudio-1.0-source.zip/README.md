# Delphi App Translation Studio

Delphi App Translation Studio is a Windows translation workspace for Delphi VCL
and FireMonkey applications. The Studio is written in Delphi with a
designer-authored FireMonkey interface and is intended to build offline JSON
language packs for Win32 and Win64 applications.

## Product Definition

The Studio is an offline-first translation-management, validation, packaging,
and Delphi-integration application. It does not require one particular source
of translated language. Translations may be prepared manually, supplied by a
human or AI assistant, imported from an external workflow, or obtained through
an optional online provider.

Translated applications load local language packs and do not require Internet
access or provider credentials. Google and DeepL support is optional and is not
the foundation of the core workflow.

The **API-Free End-to-End Translation Workflow** milestone is complete. The
professional validation record is maintained in
`docs\guides\API-Free Workflow Plan.md`.

## Current Status

The project now has a working offline translation workflow. The current source
provides:

- An FMX Studio shell using the orange-and-blue VCL2FMXConverterV6 visual family.
- Delphi `.dproj` and `.dpr` project selection.
- Automatic VCL versus FireMonkey detection.
- Win32 and Win64 target detection.
- Initial shared translation catalog and locale types.
- Versioned development-project and runtime-pack JSON schemas.
- Designer-authored VCL and FMX sample applications.
- Text `.dfm` scanning for designated VCL captions, hints, prompts, lists, and
  memo content.
- Text `.fmx` scanning for designated FMX text, hints, prompts, lists, and memo
  content.
- Delphi `resourcestring` extraction with stable unit-and-symbol keys.
- Stable form/component/property keys and source-file line locations.
- Incremental catalog merging that preserves unchanged translations, flags
  changed source text, and marks removed entries obsolete.
- A designer-authored scan-results area in the Studio.
- Project-local development catalogs under
  `Localization\Development`.
- Manual language metadata, locale-format, and translation editing.
- Explicit runtime coverage for automatically applied form properties and
  manually wired Pascal `resourcestring` entries.
- Separate translation-completeness and manual-wiring readiness summaries.
- UTF-8 CSV export/import with stable-key matching, multiline fields, stale
  source detection, duplicate/unknown-key reporting, and reviewed-work
  protection.
- Catalog validation for missing translations, duplicate keys, changed source
  text, Delphi indexed/sequential placeholders, accelerator keys, and manual
  runtime-wiring warnings.
- Context-ranked exact-source translation suggestions that require explicit
  acceptance and never inherit approval status.
- Explicit Mark Reviewed and Approve actions with enforced status progression.
- Compact offline runtime packs under `Localization\Languages`.
- Active workflow-step navigation for the six required Project, Scan,
  Languages, Validation, Export, and Integration pages, plus a separately
  labeled Optional Provider page.
- DeepL API Free/API Pro and Google Cloud Translation Basic v2 provider support.
- Masked API-key entry, Windows Credential Manager persistence, session-only
  keys, replacement, removal, and connection testing.
- Implemented optional batched provider translation that preserves reviewed
  work and marks provider results as machine translated.
- Offline VCL and FMX runtime loading, designer-persisted language menus,
  transactional integration, rollback, and deployment scripting.
- Complete line-numbered original/proposed integration diffs, mandatory
  per-file review, and explicit confirmation before Apply.
- FMX form translation through designer-persisted `OnCreate` handlers after
  form streaming; VCL startup wiring remains in the DPR.
- Win32 and Win64 API-free VCL/FMX reference pilots covering scan, CSV/JSON
  interchange, review, validation, export, integration, build, deployment, and
  required Italian offline launch behavior.

## Current Studio Workflow

1. Open a VCL or FireMonkey `.dproj` or `.dpr`.
2. Scan the project.
3. Open **Languages**, enter the target code and native language name, and create
   the development catalog.
4. Enter translations manually, export/import a CSV for an external human or
   AI-assisted workflow, accept an explicitly reviewed catalog suggestion, or
   optionally configure DeepL/Google under **Optional Provider**. Imported,
   suggested, and provider results remain marked for developer review.
5. For cataloged Pascal `resourcestring` entries, add the documented
   `TranslateText` call at each intended call site and mark manual wiring
   confirmed. The Studio does not rewrite Pascal call sites.
6. Run **Validation**.
7. When there are no validation errors, use **Export** to create the offline
   runtime JSON pack.
8. Use **Integration** to inspect the exact diff for every changed file, confirm
   review, back up, apply, or restore the target-project runtime and
   designer-authored language menu changes.

Scanning remains read-only. The `Localization` folder is created only when the
developer explicitly saves a catalog or exports a runtime pack.

## Supported Development Targets

- Translation Studio: Windows Win32 and Win64
- Translated VCL applications: Windows Win32 and Win64
- Translated FireMonkey applications: Windows Win32 and Win64

macOS, iOS, Android, Linux, and C++Builder are outside the current scope.

## Requirements

- Delphi 13 / RAD Studio 13 Florence
- Windows
- Win32 and Win64 Delphi compilers

Compatibility with other Delphi releases will be evaluated after the foundation is
stable.

## Build

Open `DelphiAppTranslationStudio.dproj` in RAD Studio and select either Win32 or
Win64.

Command-line builds can be run after loading the RAD Studio environment:

```bat
call "C:\Program Files (x86)\Embarcadero\Studio\37.0\bin\rsvars.bat"
msbuild DelphiAppTranslationStudio.dproj /t:Build /p:Config=Debug /p:Platform=Win32
msbuild DelphiAppTranslationStudio.dproj /t:Build /p:Config=Debug /p:Platform=Win64
```

Build output is written under `bin`, and compiler units are written under `dcu`.

After building all four configurations, run the FMX startup smoke test from
PowerShell:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\tools\tests\RunStudioLaunchSmokeTests.ps1
```

The test launches each Win32/Win64 Debug/Release executable, rejects startup
error dialogs, verifies the expected main-form title, and closes the test process.

## Repository Layout

```text
bin/                   Build output
dcu/                   Compiler unit output
docs/guides/           Engineering and user-facing source notes
docs/pdf/              Companion PDF documentation
export/                Generated language-pack output
help/                  Application help
images and icons/      Product artwork
samples/               VCL and FireMonkey scanner fixtures
source/core/           Framework-neutral catalog and project model
source/integration/    Target-project integration
source/provider/       Translation provider implementations
source/runtime/        Generated/runtime language support
source/scan/           VCL, FMX, and Delphi source scanners
source/schemas/        Versioned JSON schemas
source/studio/         Designer-authored FMX Studio interface
source/validation/     Catalog and integration validation
tools/tests/           Automated workflow and launch smoke tests
```

## Design Principle

Normal project scanning, translation interchange, and language-pack building are
read-only with respect to target source. Runtime and language-menu integration
is a separate exactly previewed, backed-up, developer-confirmed operation. Integrated
applications use only local JSON packs and never contain provider credentials.

## Documentation

The current product decisions and engineering findings are maintained in
[`docs/guides/Engineering Notes.md`](docs/guides/Engineering%20Notes.md).

## License

An open-source license will be added after the project owner selects the license.
